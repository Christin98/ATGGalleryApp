package com.internship.christinkoshy.atggalleryapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;

import uk.co.senab.photoview.PhotoView;

public class PhotoDetailActivityFragment extends Fragment {
    private Photo_ photo;

    public PhotoDetailActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_photo_detail, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        photo = (Photo_)getArguments().getSerializable(PhotoDetailActivity.EXTRA_PHOTO);

        PhotoView photoView = (PhotoView) view.findViewById(R.id.iv_photo);
        photoView.setScaleType(ImageView.ScaleType.FIT_CENTER);

        Glide.with(view.getContext())
                .load(photo.getUrl())
                .placeholder(R.mipmap.placeholder_photo)
                .priority(Priority.HIGH )
                .into(photoView);
    }
}
