package com.internship.christinkoshy.atggalleryapp;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.BindingAdapter;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;

public class ItemPhotoViewModel extends BaseObservable {
    private Photo_ photo;
    private Context context;

    public ItemPhotoViewModel(Context context, Photo_ photo){
        this.context = context;
        this.photo = photo;
    }

    public void onItemClick(View view) {
        context.startActivity(PhotoDetailActivity.newIntent(context, photo));
    }

    @BindingAdapter({"bind:imageUrl"})
    public static void loadImage(ImageView view, String url) {
        Glide.with(view.getContext())
                .load(url)
                .centerCrop()
                .placeholder(R.mipmap.placeholder_photo)
                .override(600, 400)
                .dontAnimate()
                .priority(Priority.HIGH )
                .into(view);
    }

    public void setPhoto(Photo_ photo){
        this.photo = photo;
        notifyChange();
    }

    public Photo_ getPhoto(){
        return this.photo;
    }
}
