package com.internship.christinkoshy.atggalleryapp;

import android.app.Application;
import android.content.Context;



public class MyApp extends Application {
    private FlickrPhotoService flickrService;

    public static MyApp get(Context context) {
        return (MyApp) context.getApplicationContext();
    }

    public FlickrPhotoService getFlickrService() {
        if (flickrService == null) {
            flickrService = FlickrPhotoService.Factory.create();
        }
        return flickrService;
    }

    //For setting mocks during testing
    public void setFlickrService(FlickrPhotoService flickrService) {
        this.flickrService = flickrService;
    }
}
