package com.internship.christinkoshy.atggalleryapp;

import android.content.Context;
import android.databinding.BaseObservable;

public class PhotoViewModel extends BaseObservable {
    private Photo_ photo;
    private Context context;

    public PhotoViewModel(Context context, Photo_ photo){
        this.context = context;
        this.photo = photo;
    }
}
