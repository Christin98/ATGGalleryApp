package com.internship.christinkoshy.atggalleryapp;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Title {
    @SerializedName("_content")
    @Expose
    private String Content;

    public String getContent() {
        return Content;
    }

    public void setContent(String Content) {
        this.Content = Content;
    }
}
